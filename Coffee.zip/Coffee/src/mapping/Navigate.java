package mapping;

import java.util.Random;

import View.*;

public class Navigate {
	public static String takes = null;
	static Random random = new Random();
	public static int dept = random.nextInt()%6+1;
	public static int arr = 6;
	public static int weight[][] = {{4,2,6,4,8,6} ,{2,4,4,2,6,4},{6,4,4,6,2,8},{4,2,6,4,4,2},{8,6,2,4,4,6},{6,4,8,2,6,4}};
	
	public static void  floyd() {
	
		/*int degree[][]= {{0}};
		int num = 6;
		
		degree = weight;
		
		for(int i =0 ; i<6; i++) {
			for(int j = 0 ; j<6; j++) {
				degree[i][j] =weight[i][j];
				if(weight[i][j]==0) {
					degree[i][j] = 10000000;
				}
			}
			
		}
		
		for(int  k =0 ; k<num  ; k++){
        	for(int i = 0 ; i <num ; i++){
            	for(int j = 0 ;j<num ; j++){
                	if(degree[i][j]>degree[i][k]+degree[k][j])
                    	degree[i][j] = degree[i][k]+degree[k][j];
            	}
        	}
    	}
		 *///launch when the weight changes
		
		
		String shop = ExpectiedTime.map();
		System.out.println(shop);
		System.out.println(weight[dept-1][arr-1]);
		
		
		takes = "�� "+weight[dept-1][arr-1]+"M";
		
	}
	
	
	
	
	
	
}

