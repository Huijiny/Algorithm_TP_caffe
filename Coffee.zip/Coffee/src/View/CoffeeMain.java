package View;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;


import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import javax.swing.plaf.basic.BasicInternalFrameTitlePane.MoveAction;

import Design.RoundedButton;

import javax.swing.JTextField;
import javax.imageio.ImageIO;
import javax.swing.Action;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.Timer;








public class CoffeeMain extends JFrame implements ActionListener {

	private JPanel contentPane;
	 private static JLabel label_1;
	 ImageIcon Lion2= new ImageIcon("/Users/sungminlee/Algorithm_TP_ANN_WordAutomation/Coffee/816170e7d63449fc17c1d7cbaaa35d044e71d7a0-2.gif");
	 ImageIcon Lion1 = new ImageIcon("/Users/sungminlee/Algorithm_TP_ANN_WordAutomation/Coffee/ezgif.com-rotate.gif");
	 //ImageIcon Lion2= new ImageIcon("/Users/sungminlee/Algorithm_TP_ANN_WordAutomation/Coffee/peach2.gif");
	//ImageIcon Lion1 = new ImageIcon("/Users/sungminlee/Desktop/eb1d1bc71d2c6d1b9716269229d1aafe4733b73b-2.gif");
	 int count = 0;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
	
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CoffeeMain frame = new CoffeeMain();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 * @throws InterruptedException 
	 */
	public CoffeeMain() {
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(300, 300, 850, 600);
		contentPane = new JPanel();
		
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		
		contentPane.setBackground(Color.ORANGE);///����///235,235,235�� �ʹ� �⺻�� ������? �Ź������� ���� �ְ��;��µ�, �ʹ� �⺻�����⵵ �ؼ���.
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		//ImageIcon title = new ImageIcon("C:\\Alg_TP\\Coffee\\title.png");
		ImageIcon title = new ImageIcon("/Users/sungminlee/Algorithm_TP_ANN_WordAutomation/Coffee/title.png");
		JLabel label = new JLabel(title);
		label.setBounds(210, 66, 428, 304);
		Font bold_ac = new Font("���� ����",Font.BOLD,60);
		label.setForeground(new Color(79,79,79));///���� ��Ʈ��
		label.setFont(bold_ac);
		label.setHorizontalAlignment(JLabel.CENTER);
		
		//ImageIcon image = new ImageIcon("C:\\Alg_TP\\Coffee\\1.png");
		ImageIcon image = new ImageIcon("/Users/sungminlee/Algorithm_TP_ANN_WordAutomation/Coffee/1.png");
		contentPane.add(label);
		
		//ImageIcon startBtn = new ImageIcon("C:\\Alg_TP\\Coffee\\startBtn.png");
		ImageIcon startBtn = new ImageIcon("/Users/sungminlee/Algorithm_TP_ANN_WordAutomation/Coffee/startBtn.png");
		//ImageIcon rolloverIcon = new ImageIcon("C:\\Alg_TP\\Coffee\\pressedBtnTitle.png");
		ImageIcon rolloverIcon = new ImageIcon("/Users/sungminlee/Algorithm_TP_ANN_WordAutomation/Coffee/pressedBtnTitle.png");
		//ImageIcon pressedIcon = new ImageIcon("C:\\Alg_TP\\Coffee\\rolloverBtnTitle.png");
		ImageIcon pressedIcon = new ImageIcon("/Users/sungminlee/Algorithm_TP_ANN_WordAutomation/Coffee/rolloverBtnTitle.png");
		JButton btnNewButton = new JButton(startBtn);
		btnNewButton.setBorderPainted(false);
		//btnNewButton.setBorder(new RoundBorder(10));
		btnNewButton.setBounds(196, 377, 454, 86);
		btnNewButton.setPressedIcon(pressedIcon);
		btnNewButton.setRolloverIcon(rolloverIcon);
		btnNewButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				SetDrinks sd = new SetDrinks();
				
				sd.setVisible(true);
				setVisible(false);
			}
			
		});
		contentPane.add(btnNewButton);
		
		//ImageIcon image2 = new ImageIcon("C:\\Alg_TP\\Coffee\\cafe.png");
		ImageIcon image2 = new ImageIcon("/Users/sungminlee/Algorithm_TP_ANN_WordAutomation/Coffee/cafe.png");
		JLabel lblNewLabel = new JLabel(image2);
		lblNewLabel.setBounds(397, 181,100, 70);
		contentPane.add(lblNewLabel);
		
		label_1= new JLabel(Lion1);
	    label_1.setHorizontalAlignment(SwingConstants.LEFT);
	    label_1.setBounds(20, 15, 118, 119);
	    MovingTextLabel();
	    getContentPane().add(label_1, BorderLayout.CENTER);
	    contentPane.add(label);
		setVisible(true);
	    setLocationRelativeTo(null);
	
	    
		
		
	
		
	}

	public void MovingTextLabel() {
	      //getContentPane().setBackground(Color.ORANGE);
	      
	      
	      label_1= new JLabel(Lion1);
	      label_1.setHorizontalAlignment(SwingConstants.LEFT);
	      label_1.setBounds(20, -5, 118, 119);
	      Timer t = new Timer(150, this); // set a timer
	      t.start();
	      setLocationRelativeTo(null);
	      
  
	      
}
	@Override
	public void actionPerformed(ActionEvent e) {
		Point point = label_1.getLocation();
	      if(count==0) {
	    	  label_1.setIcon(Lion1);
	    	  point.x+=10;
	    	  if(point.x == 780)
	    		  count = 1;
	      }
	      
	      else if(count ==1) {
	    	  label_1.setIcon(Lion2);
	    	  point.x-=10;
	    	  if(point.x == 0)
	    		  count = 0;
	      }
	      label_1.setLocation(point.x,point.y);
		
	}


	
	

	}

