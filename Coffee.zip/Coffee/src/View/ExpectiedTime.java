package View;
import java.awt.BorderLayout;
import Scheduling.*;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Design.RoundedButton;

import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;

public class ExpectiedTime extends JFrame {

	private JPanel contentPane;
	static String result = null;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ExpectiedTime frame = new ExpectiedTime();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ExpectiedTime() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Font font_plain = new Font("���� ����",Font.PLAIN,20);////�⺻��Ʈ �ٲٰ������� �ϴ� �⺻���� ��������.
		Font font_middle = new Font("���� ����",Font.BOLD,22);
		Font font_bold = new Font("���� ����",Font.BOLD,25);
		
		setBounds(300, 300, 850, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setBackground(Color.ORANGE);///����
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setBounds(306, 12, 217, 70);
		lblNewLabel.setFont(font_bold);
		lblNewLabel.setHorizontalAlignment(JLabel.CENTER);
		lblNewLabel.setText(SetDrinks.sending());		
		contentPane.add(lblNewLabel);
		
		
		JLabel lblNewLabel_4 = new JLabel("New label");
		lblNewLabel_4.setBounds(201, 377, 209, 30);
		lblNewLabel_4.setFont(font_plain);
		lblNewLabel_4.setHorizontalAlignment(JLabel.CENTER);
		String shopA = ShopA.order();
		lblNewLabel_4.setText(shopA+" ����");
		contentPane.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("New label");
		lblNewLabel_5.setBounds(424, 377, 209, 30);
		lblNewLabel_5.setFont(font_plain);
		lblNewLabel_5.setHorizontalAlignment(JLabel.CENTER);
		String shopB = ShopB.order();
		lblNewLabel_5.setText(shopB+" ����");
		contentPane.add(lblNewLabel_5);
		
		//ImageIcon back = new ImageIcon("C:\\Alg_TP\\Coffee\\backBtn.png");
		ImageIcon back = new ImageIcon("/Users/sungminlee/Algorithm_TP_ANN_WordAutomation/Coffee/backBtn.png");
		JButton btnNewButton_1 = new JButton(back);
		btnNewButton_1.setBounds(14, 12, 80, 75);
		btnNewButton_1.setBorderPainted(false);
		btnNewButton_1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				SetDrinks sd = new SetDrinks();
				sd.setVisible(true);
				setVisible(false);
			}
			
		});
		contentPane.add(btnNewButton_1);
		
		RoundedButton btnNewButton = new RoundedButton("�ֹ�");
		btnNewButton.setBounds(410, 474, 209, 55);
		btnNewButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				Navigater com = new Navigater();
				com.setVisible(true);
				setVisible(false);
				
			}
			
		});
		contentPane.add(btnNewButton);
		
		JLabel lblNewLabel_6 = new JLabel("New label");
		lblNewLabel_6.setBounds(272, 482, 111, 30);
		lblNewLabel_6.setFont(font_middle);
		lblNewLabel_6.setHorizontalAlignment(JLabel.CENTER);
		contentPane.add(lblNewLabel_6);
		lblNewLabel_6.setText(compair(shopA, shopB));
		
		//ImageIcon cafeA = new ImageIcon("C:\\Alg_TP\\Coffee\\cafes.png");
		ImageIcon cafeA = new ImageIcon("/Users/sungminlee/Algorithm_TP_ANN_WordAutomation/Coffee/cafes.png");
		JLabel lblNewLabel_7 = new JLabel(cafeA);
		lblNewLabel_7.setBounds(191, 94, 479, 300);
		
		contentPane.add(lblNewLabel_7);
		
		//ImageIcon cafeB = new ImageIcon("C:\\Alg_TP\\Coffee\\cafeB.png");
		ImageIcon cafeB = new ImageIcon("/Users/sungminlee/Algorithm_TP_ANN_WordAutomation/Coffee/cafeB.png");
		setVisible(true);
		setResizable(true);
	
	}
	
	
	public static String compair(String a, String b) {
		
		a = a.replaceAll("[^0-9]", "");
		b = b.replaceAll("[^0-9]", "");
		if(Integer.valueOf(a)<Integer.valueOf(b))
			result = "ī�� A";
		else
			result = "ī�� B";
		
		return result;
	}
	
	public static String map() {
		return result;
	}
}
