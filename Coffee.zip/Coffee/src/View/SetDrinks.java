package View;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Design.RoundedButton;
import Design.RoundedButton_plain;

import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JButton;

public class SetDrinks extends JFrame {

	private JPanel contentPane;
	
	public static class choice{
		static String select = null;
	}


	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SetDrinks frame = new SetDrinks();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public SetDrinks() {
		Font font_plain = new Font("���� ����",Font.PLAIN,20);////�⺻��Ʈ �ٲٰ������� �ϴ� �⺻���� ��������.
		Font font_middle = new Font("���� ����",Font.BOLD,22);
		Font font_bold = new Font("���� ����",Font.BOLD,25);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(300, 300, 950, 700);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setBackground(Color.ORANGE);///����
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		//ImageIcon title = new ImageIcon("C:\\Alg_TP\\Coffee\\setDrinkTitle.png");
		ImageIcon title = new ImageIcon("/Users/sungminlee/Algorithm_TP_ANN_WordAutomation/Coffee/setDrinkTitle.png");
		JLabel lblNewLabel = new JLabel(title);
		lblNewLabel.setBounds(338, 75, 408, 129);
		contentPane.add(lblNewLabel);
		
		
		//ImageIcon choosenor = new ImageIcon("C:\\Alg_TP\\Coffee\\choosenor.png");
		ImageIcon choosenor = new ImageIcon("/Users/sungminlee/Algorithm_TP_ANN_WordAutomation/Coffee/choosenor.png");
		//ImageIcon chooseroll = new ImageIcon("C:\\Alg_TP\\Coffee\\chooseroll.png");
		ImageIcon chooseroll = new ImageIcon("/Users/sungminlee/Algorithm_TP_ANN_WordAutomation/Coffee/chooseroll.png");
		//ImageIcon choosepre = new ImageIcon("C:\\Alg_TP\\Coffee\\choosepre.png");
		ImageIcon choosepre = new ImageIcon("/Users/sungminlee/Algorithm_TP_ANN_WordAutomation/Coffee/choosepre.png");
		JButton btnNewButton = new JButton(choosenor);
		btnNewButton.setBorderPainted(false);
		btnNewButton.setRolloverIcon(chooseroll);
		btnNewButton.setPressedIcon(choosepre);
		btnNewButton.setBounds(690, 536, 189, 60);
		btnNewButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				ExpectiedTime et = new ExpectiedTime();
				et.setVisible(true);
				setVisible(false);
			}
			
		});
		contentPane.add(btnNewButton);
		
		//ImageIcon ame = new ImageIcon("C:\\Alg_TP\\Coffee\\ame.png");
		//JLabel ame = new JLabel( new ImageIcon("C:\\Alg_TP\\Coffee\\menu.png"));
		JLabel ame = new JLabel( new ImageIcon("/Users/sungminlee/Algorithm_TP_ANN_WordAutomation/Coffee/menu.png"));
		ame.setBounds(271, 220, 181, 252);
		contentPane.add(ame);
		
		RoundedButton ameHot = new RoundedButton("HOT");
		ameHot.setBounds(466, 257, 100, 35);
		ameHot.setBorderPainted(false);
		ameHot.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				choice.select ="�Ƹ޸�ī��Hot";
			}
			
		});
		contentPane.add(ameHot);
		
		RoundedButton ameice = new RoundedButton("ICE");
		ameice.setBorderPainted(false);
		ameice.setBounds(586, 257, 100, 35);
		ameice.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				choice.select ="�Ƹ޸�ī��ICE";
			}
			
		});
		contentPane.add(ameice);
		
		RoundedButton latteHot = new RoundedButton("HOT");
		latteHot.setBorderPainted(false);
		latteHot.setBounds(466, 310, 100, 35);
		latteHot.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				choice.select ="ī���Hot";
			}
			
		});
		contentPane.add(latteHot);
		
		RoundedButton latteice =  new RoundedButton("ICE");
		latteice.setBorderPainted(false);
		latteice.setBounds(586, 310, 100, 35);
		latteice.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				choice.select ="ī���ICE";
			}
			
		});
		contentPane.add(latteice);
		
		RoundedButton mocaHot = new RoundedButton("HOT");
		mocaHot.setBorderPainted(false);
		mocaHot.setBounds(466, 360, 100, 35);
		mocaHot.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				choice.select ="ī���īHot";
			}
			
		});
		contentPane.add(mocaHot);
		
		RoundedButton mocaice= new RoundedButton("ICE");
		mocaice.setBorderPainted(false);
		mocaice.setBounds(586, 360, 100, 35);
		mocaice.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				choice.select ="ī���īICE";
			}
			
		});
		contentPane.add( mocaice);
		
		RoundedButton vanilHot = new RoundedButton("HOT");
		vanilHot.setBorderPainted(false);
		vanilHot.setBounds(466, 410, 100, 35);
		vanilHot.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				choice.select ="�ٴҶ��Hot";
			}
			
		});
		contentPane.add(vanilHot);
		
		RoundedButton vanilIce = new RoundedButton("ICE");
		vanilIce.setBorderPainted(false);
		vanilIce.setBounds(586, 410, 100, 35);
		vanilIce.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				choice.select ="�ٴҶ��ICE";
			}
			
		});
		contentPane.add(vanilIce);
		
		
		JLabel lblNewLabel_4 = new JLabel();
		lblNewLabel_4.setBounds(110,201,740,4);
		//ImageIcon image = new ImageIcon("C:\\Alg_TP\\Coffee\\line.png");
		ImageIcon image = new ImageIcon("/Users/sungminlee/Algorithm_TP_ANN_WordAutomation/Coffee/line.png");
		lblNewLabel_4 .setIcon(image);
		contentPane.add(lblNewLabel_4);
		
		//ImageIcon kakaof = new ImageIcon("C:\\Alg_TP\\Coffee\\kakaofriends.png");
		ImageIcon kakaof = new ImageIcon("/Users/sungminlee/Algorithm_TP_ANN_WordAutomation/Coffee/Kakaofriends.png");
		JLabel lblNewLabel_5 = new JLabel(kakaof);
		lblNewLabel_5.setBounds(0, 536, 299, 129);
		contentPane.add(lblNewLabel_5);
		
		//ImageIcon back = new ImageIcon("C:\\Alg_TP\\Coffee\\backBtn.png");
		ImageIcon back = new ImageIcon("/Users/sungminlee/Algorithm_TP_ANN_WordAutomation/Coffee/backBtn.png");
		JButton btnNewButton_1 = new JButton(back);
		btnNewButton_1.setBounds(14, 12, 80, 75);
		btnNewButton_1.setBorderPainted(false);
		btnNewButton_1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				CoffeeMain cm = new CoffeeMain();
				cm.setVisible(true);
				setVisible(false);
			}
			
		});
		contentPane.add(btnNewButton_1);
		
		ImageIcon show = new ImageIcon("/Users/sungminlee/Desktop/202314ac581228f752f86b975beb025b.gif");
		
		setVisible(true);
		setResizable(false);
	}
	
	public static String sending(){
		return choice.select;
	}
}
