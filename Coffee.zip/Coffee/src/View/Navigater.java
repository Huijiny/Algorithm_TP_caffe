package View;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.util.Random;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import javax.swing.plaf.basic.BasicInternalFrameTitlePane.MoveAction;

import Design.RoundedButton;

import javax.swing.JTextField;
import javax.imageio.ImageIO;
import javax.swing.Action;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.JButton;

import mapping.*;


public class Navigater extends JFrame {
	private JPanel contentPane;
	
	
	public Navigater() {
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(300, 300, 850, 600);
		contentPane = new JPanel();
		
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		
		contentPane.setBackground(Color.ORANGE);///배경색///235,235,235는 너무 기본색 같나요? 신문지같은 느낌 주고싶었는데, 너무 기본색같기도 해서요.
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		ImageIcon topic = new ImageIcon("/Users/sungminlee/Algorithm_TP_ANN_WordAutomation/Coffee/Map_title.png");
		
		JLabel lblNewLabel = new JLabel(topic);
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(142, 6, 570, 86);
		contentPane.add(lblNewLabel);
		
		String shop = ExpectiedTime.map();
		
		Random random = new Random();
		int dept = random.nextInt()%6+1;
		int arr = 0;
		if (shop.equals("카페 A")) {
			arr =4;
		}
		else if(shop.equals("카페 B")) {
			arr =6;
		}
		ImageIcon map1 = new ImageIcon();
		if(dept == 1&&arr == 4) {
			map1 = new ImageIcon("/Users/sungminlee/Algorithm_TP_ANN_WordAutomation/Coffee/iloveimg-resized/1-4.png");
		}
		else if(dept == 2 && arr ==4) {
			map1 = new ImageIcon("/Users/sungminlee/Algorithm_TP_ANN_WordAutomation/Coffee/iloveimg-resized/2-4.png");
		}
		else if (dept ==3 && arr ==4) {
			map1 = new ImageIcon("/Users/sungminlee/Algorithm_TP_ANN_WordAutomation/Coffee/iloveimg-resized/3-4.png");
		}
		else if (dept ==5 && arr ==4) {
			map1 = new ImageIcon("/Users/sungminlee/Algorithm_TP_ANN_WordAutomation/Coffee/iloveimg-resized/5-4.png");
		}
		else if (dept ==6 && arr ==4) {
			map1 = new ImageIcon("/Users/sungminlee/Algorithm_TP_ANN_WordAutomation/Coffee/iloveimg-resized/6-4.png");
		}
		else if (dept ==1 && arr ==6) {
			map1 = new ImageIcon("/Users/sungminlee/Algorithm_TP_ANN_WordAutomation/Coffee/iloveimg-resized/1-6.png");
		}
		else if (dept ==2 && arr ==6) {
			map1 = new ImageIcon("/Users/sungminlee/Algorithm_TP_ANN_WordAutomation/Coffee/iloveimg-resized/2-6.png");
		}
		else if (dept ==3 && arr ==6) {
			map1 = new ImageIcon("/Users/sungminlee/Algorithm_TP_ANN_WordAutomation/Coffee/iloveimg-resized/3-6.png");
			
		}
		else if (dept ==4 && arr ==6) {
			map1 = new ImageIcon("/Users/sungminlee/Algorithm_TP_ANN_WordAutomation/Coffee/iloveimg-resized/4-6.png");
		}else if (dept==5 && arr ==6) {
			map1 = new ImageIcon("/Users/sungminlee/Algorithm_TP_ANN_WordAutomation/Coffee/iloveimg-resized/5-6.png");
		}
			
		
		
		JLabel lblNewLabel_1 = new JLabel(map1);
		lblNewLabel_1.setBounds(35, 93, 793, 424);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("예상 도착시간 : ");
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setBounds(303, 529, 112, 26);
		contentPane.add(lblNewLabel_2);
		
		
		String takes_time = "약 "+Navigate.weight[dept-1][arr-1]+"M 걸림";
		JLabel lblNewLabel_3 = new JLabel(takes_time);
		lblNewLabel_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3.setBounds(427, 527, 153, 26);
		contentPane.add(lblNewLabel_3);
		
		JButton btnNewButton = new JButton("카페로 가기!");
		btnNewButton.setBounds(668, 527, 153, 29);
		btnNewButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				going cm = new going();
				cm.setVisible(true);
				setVisible(false);
				
			}
			
		});
		contentPane.add(btnNewButton);
		
		
	}
}
