package View;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;


import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import javax.swing.plaf.basic.BasicInternalFrameTitlePane.MoveAction;

import Design.RoundedButton;

import javax.swing.JTextField;
import javax.imageio.ImageIO;
import javax.swing.Action;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.Timer;

public class going extends JFrame{
	private JPanel contentPane;
	
	public going() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(300, 300, 850, 600);
		contentPane = new JPanel();
		
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		
		contentPane.setBackground(Color.ORANGE);///����///235,235,235�� �ʹ� �⺻�� ������? �Ź������� ���� �ְ��;��µ�, �ʹ� �⺻�����⵵ �ؼ���.
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		ImageIcon go = new ImageIcon("/Users/sungminlee/Algorithm_TP_ANN_WordAutomation/Coffee/ezgif.com-resize.gif");
		JLabel lblNewLabel = new JLabel(go);
		lblNewLabel.setBounds(6, 6, 838, 504);
		
		contentPane.add(lblNewLabel);
		
		JButton btnNewButton = new JButton("�ֹ��Ϸ��Ϸ�����!");
		btnNewButton.setBounds(305, 522, 226, 29);
		btnNewButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				Complete cm = new Complete();
				cm.setVisible(true);
				setVisible(false);
				
			}
			
		});
		contentPane.add(btnNewButton);
	}
	
	
	

}
