package Scheduling;
import java.util.Random;


public class ShopB {
	public static class value{
		public static String order_name[] = new String[100] ;
		public static int num[] = new int[100];
		public static int time[] = new int[100];
		public static int teskTime[] = new int[100];

	} 
	
	public static class product{
		public static String menu[] = {"Americano" , "Cafe Latte" , "Cafe Moca" , "Banila Latte" , "Caramel Macchiato" };
		public static int[] price = {4100 , 4500 , 4800 , 4800 , 5000};
	} 
	 
	private static int Menu(String select) {
		int count = 0 ;
		
		for(int i =0 ; i<5; i ++) {
			if(select.equals(product.menu[i])) {
				count++;
			}
			
		}
		return count;
		
	}
	
	public static String order() {
		
		int count = 1;
		String timeout = null;
		Random random = new Random();
		
		String select  = "Americano";
		
		int num = random.nextInt()%3+1;
		
		
		while(count<12) {
			int totalCostTime = 0;
			

			if(Menu(select)==1){
			
				order_stack(select,num,count);
				
				int made = 0 ;
				for(int i =0 ; i<count; i++) {
					if(value.time[i]*value.num[i] - value.teskTime[i]>0&&made<1) {
						totalCostTime += value.time[i]*value.num[i]-value.teskTime[i];
						value.teskTime[i] += 10;
						made++;
					}
					else if(value.time[i] - value.teskTime[i]>0&&made>=1) {
						totalCostTime += value.time[i]*value.num[i];
					}
					
				}
				
				
				if(totalCostTime%60>=10)
					timeout = totalCostTime/60 +"m "+ totalCostTime%60+"s";
				else if(totalCostTime%60>=0 &&totalCostTime%60<10)
					timeout = totalCostTime/60 +"m "+0+ totalCostTime%60+"s";
				
				count++;
				
				
			}
			
			
			
		}
		
		return timeout;
	}
	
	private static int cost_time(String select) {
		int time = 0;
		int timer[] = {40 ,60 ,60 , 80, 90};
		
		for(int i =0 ; i<5; i ++) {
			if(select.equals(product.menu[i])) {
				time += timer[i];
			}
		}
		
		return time;
	} 
	
	private static void order_stack(String select,int num,int count) {

		
		value.order_name[count-1] = select;
		value.num[count-1] = num;
		value.time[count-1] = cost_time(select);
		
		
	}
}
